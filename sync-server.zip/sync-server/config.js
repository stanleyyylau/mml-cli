
let config = {
  port: 30001
}

module.exports = config
